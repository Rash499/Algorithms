#include <iostream>
#include <cmath>
using namespace std;

int main(){
    for(int i =10; i<=30; i++){
        cout <<  sqrt(i) << endl;
    }
    return 0;
}